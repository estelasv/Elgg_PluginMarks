Plugin de calificaciones.
